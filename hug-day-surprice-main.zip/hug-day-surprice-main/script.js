<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Happy Hug Day ❤️</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="home-screen">
  <h1>Happy Hug Day ❤️</h1>
  <p>
    Tum meri life ka sabse beautiful hissa ho.  
    Tumhari ek smile mera pura din bana deti hai.  
    Kaash main abhi tumhe hug kar pata 🤗❤️
  </p>

  <button onclick="sendHug()">Send Me a Hug</button>
</div>

<script>
function sendHug(){
  alert("Virtual Hug Sent 🤗❤️");
}
</script>

</body>
</html>
